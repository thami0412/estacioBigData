from flask import Flask, render_template, request, redirect
import requests

app = Flask(__name__)

# URL do endpoint de produtos no Spring Boot
ESTOQUE_ENDPOINT = "http://localhost:8080/estoque/baixo"

# Dicionário para armazenar os níveis de estoque (parametrizações)
parametros_estoque = {}

# Menu inicial
@app.route('/')
def index():
    return render_template('index.html')

# Rota para parametrização dos níveis de estoque
@app.route('/parametrizacao', methods=['GET', 'POST'])
def parametrizacao():
    try:
        response = requests.get(ESTOQUE_ENDPOINT)
        if response.status_code == 200:
            produtos = response.json()
        else:
            produtos = []
    except requests.exceptions.RequestException as e:
        print(f"Erro ao acessar o endpoint de estoque: {e}")
        produtos = []

    if request.method == 'POST':
        for produto in produtos:
            nome = produto['nome']
            nivel_critico = request.form.get(f"nivel_critico_{nome}", type=int)
            nivel_alerta = request.form.get(f"nivel_alerta_{nome}", type=int)
            nivel_normal = request.form.get(f"nivel_normal_{nome}", type=int)
            parametros_estoque[nome] = {
                'nivel_critico': nivel_critico,
                'nivel_alerta': nivel_alerta,
                'nivel_normal': nivel_normal
            }

        return redirect('/dashboard-opcoes')

    return render_template('parametrizacao.html', produtos=produtos, parametros_estoque=parametros_estoque)

# Rota para o menu de escolha do tipo de dashboard
@app.route('/dashboard-opcoes')
def dashboard_opcoes():
    return render_template('dashboard_opcoes.html')

# Rota para exibir o gráfico
@app.route('/dashboard-grafico', methods=['GET'])
def dashboard_grafico():
    try:
        response = requests.get(ESTOQUE_ENDPOINT)
        if response.status_code == 200:
            produtos = response.json()
        else:
            produtos = []
    except requests.exceptions.RequestException as e:
        print(f"Erro ao acessar o endpoint de estoque: {e}")
        produtos = []

    # Contadores de produtos por status
    critico = 0
    alerta = 0
    normal = 0
    total = len(produtos)  # Total de produtos

    # Calcula o status de cada produto
    for produto in produtos:
        if produto['nome'] in parametros_estoque:
            niveis = parametros_estoque[produto['nome']]
            if produto['quantidade'] < niveis['nivel_critico']:
                critico += 1
            elif produto['quantidade'] < niveis['nivel_alerta']:
                alerta += 1
            else:
                normal += 1

    return render_template('dashboard_grafico.html', total=total, critico=critico, alerta=alerta, normal=normal)


# Rota para exibir a lista
@app.route('/dashboard-lista', methods=['GET'])
def dashboard_lista():
    try:
        response = requests.get(ESTOQUE_ENDPOINT)
        if response.status_code == 200:
            produtos = response.json()
        else:
            produtos = []
    except requests.exceptions.RequestException as e:
        print(f"Erro ao acessar o endpoint de estoque: {e}")
        produtos = []

    return render_template('dashboard_lista.html', produtos=produtos, parametros_estoque=parametros_estoque)

if __name__ == '__main__':
    app.run(debug=True)
